chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && /^http/.test(tab.url)) {
      const domain = new URL(tab.url).hostname;
      const apiUrl = `http://localhost:5000/api?domain=${domain}`;
      
      // Make the API call here using fetch or other methods.
      // For example:
      fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
          console.log("API Response:", data);
          // Do something with the API response data here.
        })
        .catch(error => {
          console.error("API Call Error:", error);
        });
    }
  });
  